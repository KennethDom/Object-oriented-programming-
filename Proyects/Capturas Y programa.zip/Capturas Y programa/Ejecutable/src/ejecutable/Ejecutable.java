package ejecutable;

import java.util.Scanner;
import javax.swing.JOptionPane;

public class Ejecutable {

    public static void main(String[] args) {
         
      //registrarProfesor
      
            
            
             String nombre = JOptionPane.showInputDialog(null,"Escribe el nombre del profesor");
             String apellido = JOptionPane.showInputDialog(null,"Escribe el apellido del profesor");
             int edad = Integer.parseInt(JOptionPane.showInputDialog("Dame la edad del profesor"));
             int idProfesor = Integer.parseInt(JOptionPane.showInputDialog("Dame el id del profesor"));
             int sueldo = Integer.parseInt(JOptionPane.showInputDialog("Dame el sueldo"));
             String materias = null;
             
             ProfesorTitular pT = new ProfesorTitular (idProfesor,sueldo,materias,nombre,apellido,edad);
             ProfesorInterino pI = new ProfesorInterino (idProfesor,sueldo,materias,nombre,apellido,edad);
             
             
             
             
             
             int profesor;
        profesor = Integer.parseInt(JOptionPane.showInputDialog("Selecciona tu tipo de profesor\n1.-Profesor Titular \n2.Profesor Interino"));
        
        
        //se usa switch para mostrar los datos a pantalla dependiendo del profesor que sea
        switch(profesor){
            
            case 1:   
                
                //Imprimimos todos los datos que nos dieron anteriormente 
                  JOptionPane.showMessageDialog(null, "Bienvenido profesor titular: "+nombre +" " +apellido+ "\nTu edad es de: "+edad
                     +"\nTu id es: "+idProfesor+ "\nCon un sueldo de: "+sueldo);
                        pT.calcularNomina();
                        
                  //preguntamos si desea registrar una materia
                  int pt = JOptionPane.showConfirmDialog(null, "¿Desea registrar una materia?");
                  if (pt==0){
                      pT.cargarMaterias();
                  }
                  else{
                      JOptionPane.showMessageDialog(null, "Adios");
                  }
                  
            break;
         
            case 2:
                
                //Imprimimos todos los datos que nos dieron anteriormente pero ahora con profesor interino
                  JOptionPane.showMessageDialog(null, "Bienvenido profesor interino: "+nombre +" " +apellido+ "\nTu edad es de: "+edad
                     +"\nTu id es: "+idProfesor+ "\nCon un sueldo de: "+sueldo);
                        pI.calcularNomina();
               
                         //preguntamos si desea registrar una materia
                   int pi = JOptionPane.showConfirmDialog(null, "¿Desea registrar una materia?");
                   if(pi==0){
                       pI.cargarMaterias();
                   }
                   else{
                         JOptionPane.showMessageDialog(null, "Adios");
                   }
                break;
                
            default: JOptionPane.showMessageDialog(null, "La opcion ingresada no existe");    
                
        }
        
         }
           
    }















