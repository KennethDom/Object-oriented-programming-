package ejecutable;

import java.util.ArrayList;
import javax.swing.JOptionPane;

public abstract class Profesor extends Persona {
    
    private int idProfesor;
    private double sueldo;
    String [] materias ;
    
    
    public Profesor(int idProfesor, double sueldo, String materias, String nombre, String apellido, int edad) {
        super(nombre, apellido, edad);
        this.idProfesor = idProfesor;
        this.sueldo = sueldo;
    }

    public abstract double calcularNomina();

    //Se crea un metodo para saber cauntas materis desea registrar
    public void cargarMaterias(){
        int nummaterias = Integer.parseInt(JOptionPane.showInputDialog("Cuantas materias"));
            materias = new String [nummaterias-1];
                for (int i=0; i<=nummaterias-1;i++){
                        
                        String mat = JOptionPane.showInputDialog(null,"Dame tu materia");
                        
                       JOptionPane.showMessageDialog(null, "Materia registrada: "+"\n"+mat);
                  }
                  
                 
            }    
                // getters y setters
    public int getIdProfesor() {
        return idProfesor;
    }

    public void setIdProfesor(int idProfesor) {
        this.idProfesor = idProfesor;
    }

    public double getSueldo() {
        return sueldo;
    }

    public void setSueldo(double sueldo) {
        this.sueldo = sueldo;
    }

}






































































