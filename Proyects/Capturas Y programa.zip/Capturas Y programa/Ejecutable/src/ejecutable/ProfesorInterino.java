package ejecutable;

import javax.swing.JOptionPane;

public class ProfesorInterino extends Profesor{
    private int meses;

    public ProfesorInterino(int idProfesor, double sueldo, String materias, String nombre, String apellido, int edad) {
        super(idProfesor, sueldo, materias, nombre, apellido, edad);
        this.meses = meses;
    }

    
    @Override
    public double calcularNomina(){
        //Calculamos la nomina con el siguiente metodo
            double mult = 0;
            int meses = Integer.parseInt(JOptionPane.showInputDialog("Dame tus meses trabajados"));
            double Sueldo=getSueldo();
            if (meses>6){
                mult = Sueldo *0.10;
                Sueldo = getSueldo() +mult;
                
                JOptionPane.showMessageDialog(null, "La nomina del profesor es de: "+Sueldo);
            }
            
            else{
                JOptionPane.showMessageDialog(null, "No tienes los recerrimientos para la nomina");
            }
            
        return Sueldo;
            
    }
    
    //Getters y setters
    public int getMeses() {
        return meses;
    }

    public void setMeses(int meses) {
        this.meses = meses;
    }

    
}















