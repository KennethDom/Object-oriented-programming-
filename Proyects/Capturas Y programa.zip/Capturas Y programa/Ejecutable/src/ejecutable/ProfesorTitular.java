package ejecutable;

import javax.swing.JOptionPane;

public class ProfesorTitular extends Profesor {
    
    private int antiguedad;

    public ProfesorTitular(int idProfesor, double sueldo, String materias, String nombre, String apellido, int edad) {
        super(idProfesor, sueldo, materias, nombre, apellido, edad);
        this.antiguedad = antiguedad;
    }

    
    @Override
    public double calcularNomina(){
            //Calculamos la nomina con el siguiente metodo
            
            int antiguedad = Integer.parseInt(JOptionPane.showInputDialog("Dame tu antiguedad en años"));
            double antiguedadF = antiguedad*0.05;
            double sueldo=getSueldo();
            double antiguedadFi = antiguedadF*sueldo;
            
            JOptionPane.showMessageDialog(null, "Tu nomina es de: "+antiguedadFi);
            
            return antiguedad;
    } 
            //Getters y setters
    public int getAntiguedad() {
        return antiguedad;
    }

    public void setAntiguedad(int antiguedad) {
        this.antiguedad = antiguedad;
    }

    
    
    
    
    
    
}

















