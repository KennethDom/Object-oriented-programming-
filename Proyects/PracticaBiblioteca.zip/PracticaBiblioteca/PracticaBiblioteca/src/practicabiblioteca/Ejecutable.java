package practicabiblioteca;

import javax.swing.JOptionPane;

public class Ejecutable {

    public static void main(String[] args) {
        Libro [] libros=new Libro[5];
        int i=0;
            //El ciclo para que se vaya llenando
        while (i<libros.length){
        
        int pub = JOptionPane.showConfirmDialog(null, "¿Deseas almacenar los datos de un nuevo material?");
        
        if(pub==0){
            
            int material=Integer.parseInt(JOptionPane.showInputDialog ("Que tipo de material desea registrar:\n "
                    + "1 Libro \n 2 Revista \n 3 Tesis"));
            String titulo=JOptionPane.showInputDialog ("Dame el titulo");
            int agno=Integer.parseInt(JOptionPane.showInputDialog ("Dame el año"));
            
            if (material==1){
                String autor=(JOptionPane.showInputDialog ("Dame el autor"));
                
                
                int tipoLibro=Integer.parseInt(JOptionPane.showInputDialog ("Que tipo de libro es"
                        + "\n 1 Fisico \n 2 Digital"));
                
                if(tipoLibro==1){
                    
                    System.out.println("Libro Fisico");
                    LibroFisico librosF =new LibroFisico(titulo,autor, agno);
                    
                    System.out.println(librosF);
                    
                    librosF.altaMaterial();
                }
                
                if(tipoLibro==2){
                    
                    System.out.println("Libro Digital");
                    LibroDigital lib = new LibroDigital(titulo,autor,agno);
                    
                    System.out.println(lib);
                    
                    
                    lib.altaCopia();
                    lib.bajaCopia();
                   
                    
                    int deseo=Integer.parseInt(JOptionPane.showInputDialog ("Que deseas hacer:\n "
                    + "1 Prestar \n 2 Devolver "));
                    if(deseo==1){
                        LibroDigital libs1 = new LibroDigital(titulo,autor,agno);
                          libs1.prestar();
                          i++;
                    }
                    
                    if(deseo==2){
                        LibroDigital libs2 = new LibroDigital(titulo,autor,agno);
                          libs2.devolver();
                          i++;
                    }
                }
              
        }
            
            if (material==2){
                
                String autor=(JOptionPane.showInputDialog ("Dame el autor"));
                    System.out.println("Revista");
                    Revista revistas =new Revista(titulo,autor, agno);
                    
                    System.out.println(revistas);
                    
                    revistas.altaMaterial();
                
                int deseo=Integer.parseInt(JOptionPane.showInputDialog ("Que deseas hacer:\n "
                    + "1 Prestar \n 2 Devolver "));
                    if(deseo==1){
                        Revista revista1 = new Revista(titulo,autor,agno);
                          revista1.prestar();
                          i++;
                    }
                    
                    if(deseo==2){
                        Revista revista2 = new Revista(titulo,autor,agno);
                          revista2.devolver();
                          i++;
                    }
            }
        
        if (material==3){
                
                String autor=(JOptionPane.showInputDialog ("Dame el autor"));
                    System.out.println("Tesis");
                    Tesis tesi =new Tesis(titulo,autor, agno);
                    
                    System.out.println(tesi);
                    
                    tesi.altaMaterial();
                
                int deseo=Integer.parseInt(JOptionPane.showInputDialog ("Que deseas hacer:\n "
                    + "1 Prestar \n 2 Devolver "));
                    if(deseo==1){
                        Tesis tesis1 = new Tesis(titulo,autor,agno);
                          tesis1.prestar();
                         i++;
                    }
                    
                    if(deseo==2){
                        Tesis tesis2 = new Tesis(titulo,autor,agno);
                          tesis2.devolver();
                          i++;
                    }
            }
            
        }
        
        else{
            System.out.println("Fin");
            System.exit(0);
        }
    
            }


                }
        }





































