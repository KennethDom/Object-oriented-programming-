package practicabiblioteca;
public abstract class Libro implements Publicacion {
        private String codigo;
        private String titulo;
        private String autor;
        private int agno;

    public Libro(String titulo, String autor, int agno) {
        this.titulo = titulo;
        this.autor = autor;
        this.agno = agno;
    }
    
    public abstract void tipoMaterial();

    @Override
    public String toString() {
        return "Titulo:\n" + titulo + "\n" + "Autor:\n" + autor + "\n" + "Año:\n" + agno;
    }
            
    //Metodo que genera un codigo para el libro
    @Override
    public void altaMaterial() {
        System.out.println("Codigo:");
        int num=(int)(Math.random()*100+1);
        
        codigo="LIB"+num;
        System.out.println(codigo);
    }
    
    
    
    
    
    
    
    
}


















