package practicabiblioteca;

import javax.swing.JOptionPane;

public  class LibroDigital extends Libro {
    private String numCopiaEjemplar;
    private boolean prestado;
    private String tipoMaterial;

    public LibroDigital(String titulo, String autor, int agno) {
        super(titulo, autor, agno);
        this.numCopiaEjemplar = numCopiaEjemplar;
        this.prestado = prestado;
        this.tipoMaterial = tipoMaterial;
    }

    
    @Override
    public void tipoMaterial() {
        tipoMaterial="LibroDigital";
    }
    

   
    public void altaCopia(){
        int registro;
        registro  = JOptionPane.showConfirmDialog(null, "Desea registrar un libro");
        
        if (registro==0){
        
        System.out.println("Codigo:");
        int num=(int)(Math.random()*100+1);
        
        numCopiaEjemplar="A"+num;
        System.out.println(numCopiaEjemplar);
        }
        
        else{
            
            JOptionPane.showMessageDialog (null,"Vuelva pronto");
        }
    }
    
    
    public void bajaCopia(){
        int baja;
        baja = JOptionPane.showConfirmDialog(null, "Dar de baja el libro");
        
        if (baja==0){
             String primeraLetra=numCopiaEjemplar.substring(1);
             primeraLetra="B"+primeraLetra;
            System.out.println("Tu nuevo codigo es:\n"+primeraLetra);
        }
         
        else {
            JOptionPane.showMessageDialog (null,"Vuelva pronto");
        }
    }

    //Metodos que preguntan que desea hacer
    @Override
    public void prestar() {
        int resp = JOptionPane.showConfirmDialog(null, "¿Deseas prestar el LibroDigital?");
        if(resp==0){
            prestado=true;
        }
        else{
            JOptionPane.showMessageDialog (null,"Vuelva pronto");
        }
    }

    @Override
    public void devolver() {
        int resp = JOptionPane.showConfirmDialog(null, "¿Deseas devolver el LibroDigital?");
        if(resp==0){
            prestado=false;
        }
        else{
            JOptionPane.showMessageDialog (null,"Vuelva pronto");
        }
    }

    @Override
    public void prestado() {
        if(prestado=false){
            JOptionPane.showMessageDialog(null,"Tienes prestado el libro");
        }
        else{
            prestado=true;
            JOptionPane.showMessageDialog (null,"Vuelva pronto");
        }
    }
    
    
    
}






















