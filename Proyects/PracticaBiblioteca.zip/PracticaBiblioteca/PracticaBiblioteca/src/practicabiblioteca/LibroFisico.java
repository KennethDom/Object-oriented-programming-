package practicabiblioteca;

import javax.swing.JOptionPane;

public class LibroFisico extends Libro {
    private boolean prestado;
    private String tipoMaterial;

    public LibroFisico(String titulo, String autor, int agno) {
        super(titulo, autor, agno);
        this.prestado = prestado;
        this.tipoMaterial = tipoMaterial;
    }

    
    @Override
    public void tipoMaterial() {
        tipoMaterial="LibroFisico";
    }

    
    //Metodos donde damos los valores de true y false
    @Override
    public void prestado() {
        JOptionPane.showConfirmDialog(null, prestado);
    }
    @Override
    public void prestar() {
        prestado=true;
    }

    @Override
    public void devolver() {
        prestado=false;
    }

   

    

    
}











