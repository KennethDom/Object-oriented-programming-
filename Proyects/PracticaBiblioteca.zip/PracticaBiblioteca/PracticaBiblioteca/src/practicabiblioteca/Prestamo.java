package practicabiblioteca;

public interface Prestamo {
        public void prestar ();
        public void devolver ();
        public void prestado ();
}


