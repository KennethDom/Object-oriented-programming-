package practicabiblioteca;
public interface Publicacion extends Prestamo {
    
      
      public void altaMaterial ();
      
      
}






