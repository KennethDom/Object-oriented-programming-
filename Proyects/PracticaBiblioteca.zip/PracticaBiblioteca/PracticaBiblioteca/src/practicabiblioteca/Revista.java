package practicabiblioteca;

import javax.swing.JOptionPane;

public class Revista implements Publicacion {
    private String codigo;
    private boolean prestado;
    private String titulo;
    private String autor;
    private int agno;    

    public Revista(String titulo, String autor, int agno) {
        this.titulo = titulo;
        this.autor = autor;
        this.agno = agno;
    }

    //Metodo tostring para poder imprimir las respuestas
    @Override
    public String toString() {
         return "Titulo:\n" + titulo + "\n" + "Autor:\n" + autor + "\n" + "Año:\n" + agno;
    }
    
    
    
    //Metodo que genera un codigo para la revista
       @Override
    public void altaMaterial() {
        System.out.println("Codigo:");
        int num=(int)(Math.random()*100+1);
        
        codigo="REV"+num;
        System.out.println(codigo);
    }

    //Metodos que preguntan que desea hacer
    @Override
    public void prestar() {
        int resp = JOptionPane.showConfirmDialog(null, "¿Deseas prestar la Revista?");
        if(resp==0){
            prestado=true;
            System.out.println("Prestaste la revista");
        }
        else{
            JOptionPane.showConfirmDialog(null,"Vuelva pronto");
        }
    }

    @Override
    public void devolver() {
        int resp = JOptionPane.showConfirmDialog(null, "¿Deseas devolver la Revista?");
        if(resp==0){
            prestado=false;
            System.out.println("Devolviste la revista");
        }
        else{
            JOptionPane.showConfirmDialog(null,"Vuelva pronto");
        }
    }

    @Override
    public void prestado() {
        if(prestado=false){
            JOptionPane.showConfirmDialog(null,"Devolviste la Revista");
        }
        else{
            prestado=true;
            JOptionPane.showConfirmDialog(null,"Prestaste la Revista");
        }
    }

   
    
}












