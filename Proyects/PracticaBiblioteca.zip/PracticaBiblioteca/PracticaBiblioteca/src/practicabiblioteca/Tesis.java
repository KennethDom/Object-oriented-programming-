package practicabiblioteca;

import javax.swing.JOptionPane;

public class Tesis implements Publicacion {
    private String codigo;
    private boolean prestado;
    private String titulo;
    private String autor;
    private int agno;  

    public Tesis(String titulo, String autor, int agno) {
        this.titulo = titulo;
        this.autor = autor;
        this.agno = agno;
    }

    
     //Metodo tostring para poder imprimir las respuestas
    @Override
    public String toString() {
         return "Titulo:\n" + titulo + "\n" + "Autor:\n" + autor + "\n" + "Año:\n" + agno;
    }
    
    
    
    //Metodo que genera un codigo para la tesis
         @Override
    public void altaMaterial() {
        System.out.println("Codigo:");
        int num=(int)(Math.random()*100+1);
        
        codigo="TES"+num;
        System.out.println(codigo);
    }

    
    //Metodos que preguntan que desea hacer
   @Override
    public void prestar() {
        int resp = JOptionPane.showConfirmDialog(null, "¿Deseas prestar el LibroDigital?");
        if(resp==0){
            prestado=true;
            System.out.println("Prestaste la tesis");
        }
        else{
            JOptionPane.showConfirmDialog(null,"Vuelva pronto");
        }
    }

    @Override
    public void devolver() {
        int resp = JOptionPane.showConfirmDialog(null, "¿Deseas devolver la Tesis?");
        if(resp==0){
            prestado=false;
            System.out.println("Devolviste la tesis");
        }
        else{
            JOptionPane.showConfirmDialog(null,"Vuelva pronto");
        }
    }

    @Override
    public void prestado() {
        if(prestado=false){
            JOptionPane.showConfirmDialog(null,"Devolviste la Tesis");
        }
        else{
            prestado=true;
            JOptionPane.showConfirmDialog(null,"Prestaste la Tesis");
        }
    }
    
    
    
}












