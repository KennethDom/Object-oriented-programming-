package supermercado;
public class Supermercado {

    public static void main(String[] args) {
         
                 double iva=(double) 0.16;
                 double resultado;
        
         Articulo producto1= new Articulo ();
         producto1.setClave(0001);
         producto1.setDescripcion("Fresco y en buenas condicones");
         producto1.setPrecio(289*iva);
         
         
         Articulo producto2=new Articulo ();
         producto2.setClave(0002);
         producto2.setDescripcion("Biodegradable y con olor agradable");
         producto2.setPrecio(129*iva);
         
         Articulo producto3=new Articulo ();
         producto3.setClave(0003);
         producto3.setDescripcion("Acido y de buen sabor");
         producto3.setPrecio(193*iva);
         
         System.out.println("El producto 1 es   "+producto1.getDescripcion());
         System.out.println("Clave del producto 1:  "+producto1.getClave());
         System.out.println("Precio del producto 1  "+producto1.getPrecio());
         
         System.out.println("El producto 2 es   "+producto2.getDescripcion());
         System.out.println("Clave del producto 2:  "+producto2.getClave());
         System.out.println("Precio del producto 2  "+producto2.getPrecio());
         
         System.out.println("El producto 3 es   "+producto3.getDescripcion());
         System.out.println("Clave del producto 3:  "+producto3.getClave());
         System.out.println("Precio del producto 3  "+producto3.getPrecio());
         
         resultado=+producto1.getPrecio()+producto2.getPrecio()+producto3.getPrecio();
         
            System.out.println("El precio total que pagaras es de " + resultado);
         
                    }
    }
    




























