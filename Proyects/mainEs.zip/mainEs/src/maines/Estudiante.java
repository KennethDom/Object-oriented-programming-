package maines;


public class Estudiante {
    private String nombre;
    private int semestre;
    private String fechaNac;
    private double promedio;
    
    //atributos para fecha
    public int dia;
    public int mes;
    public int año;

    public Estudiante() {
    }

    public Estudiante(String nombre, int semestre, String fechaNac, double promedio) {
        this.nombre = nombre;
        this.semestre = semestre;
        this.fechaNac = fechaNac;
        this.promedio = promedio;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public int getSemestre() {
        return semestre;
    }

    public void setSemestre(int semestre) {
        this.semestre = semestre;
    }

    public String getFechaNac() {
        return fechaNac;
    }

    public void setFechaNac(String fechaNac) {
        this.fechaNac = fechaNac;
    }

    public double getPromedio() {
        return promedio;
    }

    public void setPromedio(double promedio) {
        this.promedio = promedio;
    }

    public int getDia() {
        return dia;
    }

    public void setDia(int dia) {
        this.dia = dia;
    }

    public int getMes() {
        return mes;
    }

    public void setMes(int mes) {
        this.mes = mes;
    }

    public int getAño() {
        return año;
    }

    public void setAño(int año) {
        this.año = año;
    }


    
}













