package maines;

import java.util.Scanner;
import java.text.DecimalFormat;

public class MainEs {

    public static void main(String[] args) {
        
        Estudiante Estudiante1 =new Estudiante ();
        Estudiante1.setNombre("Ismael Falco Cristobal");
        Estudiante1.setFechaNac("");
        Estudiante1.setPromedio(89.50);
        Estudiante1.setSemestre(3);
        
        Estudiante Estudiante2=new Estudiante();
        Estudiante2.setNombre("Miguel Angel Hierro");
        Estudiante2.setFechaNac("");
        Estudiante2.setPromedio(90.10);
        Estudiante2.setSemestre(5);
        
        Estudiante Estudiante3=new Estudiante();
        Estudiante3.setNombre("Marcos Casillas Galvan");
        Estudiante3.setFechaNac("");
        Estudiante3.setPromedio(79.10);
        Estudiante3.setSemestre(7);
        
        
        //materias solamente 6 dar valores
     
        Scanner materiaa =new Scanner(System.in);
        String materia1;
        
        System.out.println("Cual es la 1ra materia de "+Estudiante1.getNombre());
        materia1 = materiaa.nextLine();
        
        
        Scanner materiab =new Scanner(System.in);
        String materia2;
        
        System.out.println("¿Cual es tu 2da materia? ");
        materia2 = materiab.nextLine();
        
        
        Scanner materiac =new Scanner(System.in);
        String materia3;
        
        System.out.println("¿Cual es tu 3ra materia? ");
        materia3 = materiac.nextLine();
        
        
        Scanner materiad =new Scanner(System.in);
        String materia4;
        
        System.out.println("¿Cual es tu 4ta materia? ");
        materia4 = materiad.nextLine();
        
        
        Scanner materiae =new Scanner(System.in);
        String materia5;
        
        System.out.println("¿Cual es tu 5ta materia? ");
        materia5 = materiae.nextLine();
        
        
        Scanner materiaf =new Scanner(System.in);
        String materia6;
        
        System.out.println("¿Cual es tu 6ta materia? ");
        materia6 = materiaf.nextLine();
        
        
        //Calificaciones de las materias
        
        Scanner materiaac =new Scanner(System.in);
        double materia1ac;
        System.out.println("Cual es la calificacion total de "+materia1);
        materia1ac = materiaac.nextDouble();
        
        //System.out.println("Calificacion total de "+materia1+" "+materia1ac);
        
         Scanner materiabc =new Scanner(System.in);
        double materia2bc;
        System.out.println("Cual es la calificacion total de "+materia2);
        materia2bc = materiabc.nextDouble();
        
        //System.out.println("Calificacion total de "+materia2+" "+materia2bc);
        
         Scanner materiacc =new Scanner(System.in);
        double materia3cc;
        System.out.println("Cual es la calificacion total de "+materia3);
        materia3cc = materiacc.nextDouble();
        
        //System.out.println("Calificacion total de "+materia3+" "+materia3cc);
        
         Scanner materiadc =new Scanner(System.in);
        double materia4dc;
        System.out.println("Cual es la calificacion total de "+materia4);
        materia4dc = materiadc.nextDouble();
        
        //System.out.println("Calificacion total de "+materia4+" "+materia4dc);
        
         Scanner materiaec =new Scanner(System.in);
        double materia5ec;
        System.out.println("Cual es la calificacion total de "+materia5);
        materia5ec = materiaec.nextDouble();
        
        //System.out.println("Calificacion total de "+materia5+" "+materia5ec);
        
         Scanner materiafc =new Scanner(System.in);
        double materia6fc;
        System.out.println("Cual es la calificacion total de "+materia6);
        materia6fc = materiafc.nextDouble();
        
        //System.out.println("Calificacion total de "+materia6+" "+materia6fc);
        
        //Calculo de promedio
        DecimalFormat promTotal=new DecimalFormat("#.00");
        double promedio = materia1ac +materia2bc +materia3cc +materia4dc +materia5ec +materia6fc;
        double promTotalF=promedio/6;
        System.out.println("Tu nuevo promedio total es de "+promTotal.format(promTotalF));        
         
        
        //Calculo de practicas profesionales
        Scanner semestre =new Scanner(System.in);
        int semestreAc;
        System.out.println("Dime tu semestre actual");
        semestreAc= semestre.nextInt();
        
        
                    //Practicas profesionales
        
                 if(semestreAc>=7 && semestreAc<16 ){
                     System.out.println("Estas listo para realizar tus practicas profesionales");
                 }
                 else{
                     System.out.println("Lo siento, no puedes realizar tus praticas profesionales");
                 }
                 
        Scanner dia =new Scanner(System.in);
        int diaF = 0;
        int diaNac;
        
        System.out.println("¿Cual es el dia de tu nacimiento? ");
        diaNac = dia.nextInt();
         if (diaNac>0 && diaNac>32){
                System.out.println("El dia es incorrecto");
        } else {
                diaF=diaNac;
         }
        Scanner mes =new Scanner(System.in);
        int mesF = 0;
        int mesNac;
        
        System.out.println("¿Cual es el mes de tu nacimiento? ");
        mesNac = mes.nextInt();
                 if (mesNac>=0 && mesNac>12){
                    System.out.println("El mes es incorrecto");
        } else {
                     mesF=mesNac;
                 }
        
        
        Scanner año =new Scanner(System.in);
        int añoF = 0;
        int añoNac;
        
        System.out.println("¿Cual es el año de tu nacimiento? ");
        añoNac = año.nextInt();
        if (añoNac<1900 && añoNac<2021){
            System.out.println("El año es incorrecto");
        } else {
            añoF=añoNac;
        }
        
        System.out.println("Tu dia de ncimiento es de "+diaF  + " "+mesF +" "+añoF);
                 
            }
    }
    



























































































