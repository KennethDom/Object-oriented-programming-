package maines;
public class edad {
        public int dia;
        public int mes;
        public int año;
    public edad(int dia, int mes, int año) {
        
}

    public int getDia() {
        return dia;
    }

    public final void setDia(int dia) {
        
        this.dia = dia;
    }

    public int getMes() {
        return mes;
    }

    public final void setMes(int mes) {
        this.mes = mes;
    }

    public int getAño() {
        return año;
    }

    public final void setAño(int año) {
        this.año = año;
    }
    
    
    
}





